from django.shortcuts import render
from django.http import HttpResponse
import json
import urllib2
from persones.models import Persona
from django.db.models import Q
from django.core.paginator import Paginator

# Create your views here.

def getPersones(request):
   
    q=request.GET.get( 'q', '' )
    page=int( request.GET.get( 'page', 1 ) )
    
    
    q_nom = Q( nom__icontains=q )
    q_cognom = Q( cognom__icontains=q )
    
    totes_les_persones = Persona.objects.filter(q_nom | q_cognom )
    
    totes_les_pagines = Paginator(totes_les_persones, 30)
    
    persones = [ {'id':p.id,
                  'nom': p.nom,
                  'cognoms': p.cognom }
                for p in  totes_les_pagines.page( page )  ]

    values = json.dumps( 
                { 'numero': totes_les_persones.count(),
                  'items': persones
                })
    
    return HttpResponse(values, content_type='application/json')
    
    
    
def personesTest (request):
  return render(request, 'persones/test.html', )
  