from django.conf.urls import url, include
from persones import views


urlpatterns = [
    url(r'^apiPersones/', views.getPersones, name='apiPersones'),
    url(r'^test/', views.personesTest, name='test'),
    