# encoding: utf-8
from __future__ import unicode_literals
from django.db import models

class Persona (models.Model):
    nom=models.CharField(max_length=300, help_text="Nom.")
    cognom=models.CharField(max_length=400, help_text="Cognom.")