from django.apps import AppConfig


class PersonesConfig(AppConfig):
    name = 'persones'
